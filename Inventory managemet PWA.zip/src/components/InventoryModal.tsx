import React, { useState, useEffect } from 'react';
import { supabase } from '../supabaseClient';
import { X, Sparkles, Save, Info } from 'lucide-react';
import confetti from 'canvas-confetti';

interface InventoryItem {
  id: string;
  name: string;
  sku: string;
  category: string;
  quantity: number;
  min_stock_level: number;
  price: number;
  location?: string;
  image_url?: string;
  description?: string;
  box_id?: string | null;
}

interface InventoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
  userId: string;
  editItem?: InventoryItem | null;
  boxId?: string | null;
}

const CATEGORIES = [
  'General',
  'Electronics',
  'Office Supplies',
  'Furniture',
  'Apparel',
  'Food & Beverage',
  'Raw Materials',
  'Tools & Equipment',
  'Packaging'
];

export const InventoryModal: React.FC<InventoryModalProps> = ({
  isOpen,
  onClose,
  onSave,
  userId,
  editItem = null,
  boxId = null,
}) => {
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [category, setCategory] = useState('General');
  const [quantity, setQuantity] = useState(0);
  const [minStock, setMinStock] = useState(5);
  const [price, setPrice] = useState(0.0);
  const [location, setLocation] = useState('');
  const [imageUrl, setImageUrl] = useState('');
  const [description, setDescription] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (editItem) {
      setName(editItem.name);
      setSku(editItem.sku || '');
      setCategory(editItem.category || 'General');
      setQuantity(editItem.quantity);
      setMinStock(editItem.min_stock_level);
      setPrice(editItem.price);
      setLocation(editItem.location || '');
      setImageUrl(editItem.image_url || '');
      setDescription(editItem.description || '');
    } else {
      setName('');
      setSku('');
      setCategory('General');
      setQuantity(0);
      setMinStock(5);
      setPrice(0.0);
      setLocation('');
      setImageUrl('');
      setDescription('');
    }
    setError(null);
  }, [editItem, isOpen]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('Product Name is required.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const itemData = {
        user_id: userId,
        name: name.trim(),
        sku: sku.trim() || null,
        category,
        quantity,
        min_stock_level: minStock,
        price,
        location: location.trim() || null,
        image_url: imageUrl.trim() || null,
        description: description.trim() || null,
        box_id: editItem ? editItem.box_id : (boxId || null),
      };

      if (editItem) {
        // Update existing item
        const { error: updateError } = await supabase
          .from('inventory_items')
          .update(itemData)
          .eq('id', editItem.id);

        if (updateError) throw updateError;

        // Log transaction if quantity changed
        const qtyDiff = quantity - editItem.quantity;
        if (qtyDiff !== 0) {
          const { error: txError } = await supabase
            .from('stock_transactions')
            .insert({
              item_id: editItem.id,
              user_id: userId,
              type: qtyDiff > 0 ? 'IN' : 'OUT',
              quantity: qtyDiff,
              notes: `Manual quantity update (from ${editItem.quantity} to ${quantity})`,
            });
          if (txError) console.error('Error logging transaction:', txError);
        }
      } else {
        // Create new item
        const { data, error: insertError } = await supabase
          .from('inventory_items')
          .insert(itemData)
          .select()
          .single();

        if (insertError) throw insertError;

        // Log transaction for initial quantity
        if (quantity > 0 && data) {
          const { error: txError } = await supabase
            .from('stock_transactions')
            .insert({
              item_id: data.id,
              user_id: userId,
              type: 'IN',
              quantity: quantity,
              notes: 'Initial stock intake',
            });
          if (txError) console.error('Error logging transaction:', txError);
        }

        // Fire success confetti!
        confetti({
          particleCount: 80,
          spread: 60,
          origin: { y: 0.7 }
        });
      }

      onSave();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Error saving inventory item.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()}>
        {/* Modal Header */}
        <div style={styles.modalHeader}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={styles.modalHeaderBadge}>
              <Sparkles size={18} style={{ color: '#fff' }} />
            </div>
            <h2 style={{ fontSize: '1.25rem', fontWeight: 600 }}>
              {editItem ? 'Edit Product' : 'Add New Product'}
            </h2>
          </div>
          <button style={styles.closeBtn} onClick={onClose}>
            <X size={20} />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} style={styles.form}>
          {error && (
            <div style={styles.errorBanner}>
              <Info size={16} style={{ flexShrink: 0 }} />
              <span>{error}</span>
            </div>
          )}

          <div style={styles.gridTwoCols}>
            <div className="form-group">
              <label className="form-label">Product Name *</label>
              <input
                type="text"
                className="form-control"
                placeholder="e.g. Ergonomic Office Chair"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">SKU / Barcode</label>
              <input
                type="text"
                className="form-control"
                placeholder="e.g. CHR-ERG-001"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
              />
            </div>
          </div>

          <div style={styles.gridTwoCols}>
            <div className="form-group">
              <label className="form-label">Category</label>
              <select
                className="form-control"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                style={{ appearance: 'none' }}
              >
                {CATEGORIES.map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Warehouse Location</label>
              <input
                type="text"
                className="form-control"
                placeholder="e.g. Aisle 3, Shelf B"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>
          </div>

          <div style={styles.gridThreeCols}>
            <div className="form-group">
              <label className="form-label">Quantity</label>
              <input
                type="number"
                min="0"
                className="form-control"
                value={quantity}
                onChange={(e) => setQuantity(Math.max(0, parseInt(e.target.value) || 0))}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Min Stock Alert</label>
              <input
                type="number"
                min="0"
                className="form-control"
                value={minStock}
                onChange={(e) => setMinStock(Math.max(0, parseInt(e.target.value) || 0))}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Unit Price ($)</label>
              <input
                type="number"
                min="0"
                step="0.01"
                className="form-control"
                value={price}
                onChange={(e) => setPrice(Math.max(0, parseFloat(e.target.value) || 0))}
              />
            </div>
          </div>

          <div className="form-group">
            <label className="form-label">Product Image URL</label>
            <input
              type="url"
              className="form-control"
              placeholder="https://images.unsplash.com/... or generate an image asset"
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
            />
          </div>

          <div className="form-group" style={{ marginBottom: '10px' }}>
            <label className="form-label">Description</label>
            <textarea
              className="form-control"
              placeholder="Provide key notes, product dimensions, materials..."
              rows={3}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              style={{ resize: 'vertical' }}
            />
          </div>

          {/* Form Actions */}
          <div style={styles.formActions}>
            <button type="button" className="btn btn-secondary" onClick={onClose} disabled={loading}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={loading}>
              {loading ? (
                <span style={styles.spinner}></span>
              ) : (
                <>
                  <Save size={18} />
                  <span>{editItem ? 'Save Changes' : 'Create Product'}</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const styles: Record<string, React.CSSProperties> = {
  modalHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '20px 24px',
    borderBottom: '1px solid var(--border-color)',
  },
  modalHeaderBadge: {
    width: '32px',
    height: '32px',
    borderRadius: 'var(--radius-sm)',
    background: 'linear-gradient(135deg, var(--primary), var(--secondary))',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeBtn: {
    background: 'none',
    border: 'none',
    color: 'var(--text-secondary)',
    cursor: 'pointer',
    padding: '4px',
    borderRadius: 'var(--radius-sm)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'all var(--transition-fast)',
  },
  form: {
    padding: '24px',
    display: 'flex',
    flexDirection: 'column',
    gap: '4px',
  },
  gridTwoCols: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '20px',
  },
  gridThreeCols: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr 1fr',
    gap: '16px',
  },
  formActions: {
    display: 'flex',
    justifyContent: 'flex-end',
    gap: '12px',
    marginTop: '20px',
    borderTop: '1px solid var(--border-color)',
    paddingTop: '20px',
  },
  errorBanner: {
    display: 'flex',
    gap: '10px',
    alignItems: 'center',
    padding: '12px 16px',
    background: 'var(--danger-glow)',
    border: '1px solid hsla(350, 80%, 55%, 0.3)',
    borderRadius: 'var(--radius-md)',
    color: 'var(--danger)',
    fontSize: '0.9rem',
    marginBottom: '16px',
  },
  spinner: {
    width: '18px',
    height: '18px',
    border: '2px solid rgba(255, 255, 255, 0.3)',
    borderTopColor: '#fff',
    borderRadius: '50%',
    display: 'inline-block',
    animation: 'spin 0.8s linear infinite',
  },
};
// Note: Animation styling injected by Auth.tsx already covers spinning
export default InventoryModal;
