export interface UserSettings {
  // Stock Alert Settings
  defaultMinStockLevel: number;
  lowStockWarningEnabled: boolean;
  outOfStockWarningEnabled: boolean;
  showLowStockOnHome: boolean;
  alertAtZero: boolean;

  // Room / Box Settings
  defaultRoomId: string | null;
  defaultBoxId: string | null;
  archiveEmptyBoxes: boolean;
  blockDeleteRoomWithItems: boolean;
}

export const DEFAULT_USER_SETTINGS: UserSettings = {
  defaultMinStockLevel: 5,
  lowStockWarningEnabled: true,
  outOfStockWarningEnabled: true,
  showLowStockOnHome: true,
  alertAtZero: true,
  defaultRoomId: null,
  defaultBoxId: null,
  archiveEmptyBoxes: false,
  blockDeleteRoomWithItems: true,
};

/** Merge a partial DB settings JSONB with the defaults so we never have undefined keys */
export function mergeSettings(partial: Partial<UserSettings>): UserSettings {
  return { ...DEFAULT_USER_SETTINGS, ...partial };
}
